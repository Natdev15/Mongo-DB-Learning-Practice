// Inserting Data in Mongo 

// first we'll open 2 Powershell's then in first we'll write "mongod" and
// in second one we'll write "mongo" 

// then in second one Powershell we'll write "use nateshCraft" 

use nateshCraft

// then we'll create database in it here we'll write and then paste it 
// on that "Powershell" adn then press "Enter"

// here we'll use "insertOne()" function and in this func we just write 1 object or data 

db.items.insertOne({name: "Natesh", age: 20, address: "Karimabad Town", city: "Mpk"})

// and now we copied it and paste it on that "Powershell"

// jese hi hum yeh upar wala copied karengy waha "Right click" krne pe phir hum
// daikhengy k hamar database agya hai kisi unique "object Id" se 
// or hum isko check k liye "db.item.find()" likhengy 
// db.item.find()



// here we'll use "insertMany()" function and in this we can Insert many database
// through one function but in this we'll have insert "Array" before 
// inserting "Object"

db.items.insertMany([{name: "natu", age: 21, address: "Karim town"},
{name:"ahmad", age: 22, address: "Nimra Town", city: "Mpk"}, 
{name:"Deepak", age: 21, address: "Scheme no:02", city: "mpk", PstCode: 69000}])

// ab hum isko bhi copy krke waha paste krengy or "db.item.find()" iske sath find() function 
// lagayengy toh usmei hamara purana wala database or yeh wala dono show houngy 
// jo humne "db.item" means "items" database mei put ki thi woh 



// here we'll also use this "insertMany()" function 

db.items.insertMany([{Mobile_name: "Samsung", model: "A012s", price: 24500, rating: 9.6},
{Mobile_name: "Oppo", model: "A15s", price: 23500, rating: 7.0},
{Mobile_name: "Infinix", model: "Hot 10", price: 20500, rating: 10}])

// isko copy krke paste krengy or phir 
// hum phir "db.items.find()" likhengy toh sab ajayengy "items" databse wale 


// or hum "show collections" likhengy toh humei show krega k hamare kitne database hai 
// or humei filal 1 hi dikhayega woh hoga "items" 


// or "show dbs" karengy toh sarey databases k names humei show krega samne
// or unki ussage memory bhi 




// yeh niche wali line isliye kyuke "nateshCrafts" mei woh switched hojaye 
// use nateshCrafts 

db.items.insertMany([
    {name: "Nitu", age: 20}, {name: "niku", age: 21}, {name: "nitesh", age: 21},
    {name: "Natu", age: 20}, {name: "Natesh", age: 21}
])


// agar hum " db.items.find() " likhe toh saari data ajayegai jo humne "nateshCrafts"
// k "items" database mei di hai  
db.items.find() 



// agar humei specific data chaiye like phle yeh code likhe
db.items.insertMany( [
    {name: "Samsung", model: "A012s", price: 24500, rating: 9.9},
    {name: "Oppo", model: "A15s", price: 23500, rating: 10.2},
    {name: "Infinx", model: "Hot 10", price: 20500, rating: 8.9}
] )

// then ab hum apply kerngy 
db.items.find({ rating: 8.9} )
// agar hum yeh likhengy toh yeh humei wohi items k database mei se data dikhayega
// jismei "rating: 8.9" hogi jo humne manghi hai 


// yeh niche wala humei database mei se un sab kilist dikhayega
// jismei "rating 8.9 y aussey barhi hoga" "gte = greater than  equal to"
db.items.find({ rating: {$gte: 8.9} })
// or enter krte yeh list dikhayega 


// AND Oprator in Mongodb: ismei hum "," comma lagha kar dusra object
// function apply krengy 
// niche line mei likha hai jese humei "list of object dikhaey jismei "rating greter than 8.9 ho"
// or jiski "price greaater than 20000" ho means dono condition apply ho
db.items.find({ rating: {$gt: 8.9}, price: {$gt: 20000} })
// or yeh list generate krega 



db.items.insertMany( [
    {name: "realme", rating: 9.0, price: 23000}, 
    {name: "tecno", rating: 8.7, price: 14000},
    {name: "sparko", rating: 7.0, price: 14500}
 ] )



// niche line mei hum yeh likhengy k jiski rating "8.0" k barabar ho ya greater ho 
// or sath hi sath price uski "15000" k barabar ho ya ussey ziada hogi uski list dikhao 
db.items.find({rating: {$gte: 8.0} , price: {$gte: 15000} })
// list ajayegi or upar ismei "AND Operator" lagaya hua hai


// niche wali line mei jiski value less then & equal hogi woh show krega 
// "lt = less than" and "lte = less than and equal to"
db.items.find({rating: {$lte: 8.0} , price: {$lte: 15000} })
// upar wali mei woh show krega jiski less than or equal to "Rating: 8.0" or "Price: 15000" ho 


db.items.find({rating: {$lt: 8.0} , price: {$lt: 15000} })
// upar wali mei woh show krega jiski less than "Rating: 8.0" or "Price: 15000" ho 



db.items.find({rating: {$lt: 8.0} , price: {$lt: 14000} })
// upar wali mei woh show krega jiski less than "Rating: 8.0" or "Price: 15000" ho 



// OR Operator in Mongodb: ismei hum "[]" array ki madad lehngy phir jo pouchengy
// usmei se dono mei se 1 cheez true hogi toh uska bh ajyega 
db.items.find({
    $or:[ {rating: {$gt: 8.0} }, {price: {$lt: 20000}} ]
})
// is upar wale function mei yeh hoga k "or" Operator laghaya hai toh dono mei 
// se agar 1 bhi condition sahi hogi toh chla jayega 



db.items.find({ 
    $or:[ {rating: {$gte: 9}}, {price: {$gte: 17000}}]
})
// upar wali conditon mei yeh hoga woh bhi ayega jiski rating "greater than equal to 9" hogi 
// or woh bhi jiski price "greater than equal to 17000" hogi 



// AND Operator 
db.items.find({ rating: {$gte: 9}, price: {$gte: 17000} })


// AND Operator
db.items.find({ rating: {$gt: 9}, price: {$gt: 17000} })



// OR operator
db.items.find({name : "samsung", name: "oppo"}) 



// yeh niche wale mei humne kaha hai jiska name "realme" hai woh or
// jiski rating "8.0" woh hsow kre 
db.items.find({name: "realme", rating: "8.0" })



// niche wale mei humne kaha hai jiska name "realme" hai woh ya means "or conditon"
// jiski rating "8.0" ho woh unki list show kre 
db.items.find({$or:[{name: "realme"}, {rating: "8.0"} ] })


// yeh  niche wali mei yeh hoga k jo bhi age = 20 ya 20 se barhi hogi woh list ajayegi 
db.items.find({age: {$gte: 20} })



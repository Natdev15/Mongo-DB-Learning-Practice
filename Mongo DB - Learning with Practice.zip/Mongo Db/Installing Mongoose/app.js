const fs = require("fs");
const validator = require("validator");
const path = require("path");
const express = require("express");
const app = express();
// "npm i pug" for pug installation in terminal
// "npm i express" for express installation in terminal
// "npm i mongoose" for mongoose installation in terminal
// "npm i path" for path installation in terminal
// "npm i validator" for validator installation in terminal

// const mongoose = require("mongoose");
// mongoose.connect('mongodb://localhost/nateshCraft', 
// {useNewUrlParser: true, useUnifiedTopology: true});


// const db = mongoose.connection;
// db.on('error', console.error.bind(console, 'connection error:'));
// db.once('open', function() {
  //   console.log('we"re connected!');
  // });
  
// now in terminal put "node app.js" then we'll connected if our code is correct



// creating Schema: where we defined about type of our data which we'll insert into our database 

// const nateshSchema = new mongoose.Schema({
//   name: String,
//   age: Number
// })

// humne yeh define kiya hai k name jo bhi hoga woh String form mei hoga or
// age wagera number form mei 



// now we are Creating Model in which we complied our Schema that we have decide our
// model and we are going to insert data in this form 

// const nitu = mongoose.model('nitu', nateshSchema)

// ismei humne model banaya hai jismei model or usmie apna Schema include krdiya hai
// ab yeh "nitu" hamare "nateshCraft" wale database k collection mei "nitus" name se insert hoga
// kyuke "Plural" mei hojaeyga jo bhi hum "Model" banate hue likhengy woh 


// now we are creating Document object method by which we add our data easily into 
// tell that this is our data and it's behavior  

// const nateshKitty1 = new nitu({name: "Natesh"})
// const nateshKitty2 = new nitu({name: "Natesh Kumar Nenwani"})
// const nateshKitty2 = new nitu({name: "Natu"})

// upar humne 2 document methods banaye hai jisemi 1 mei name: "Natesh" hai or 
// second mei name: "Natu" hai.



// now we'll save it into our database's Collection 

//  nateshKitty1.save(function (err, nateshKitty1){
//   if(err) console.error(err);
// });

// nateshKitty2.save(function (err, nateshKitty2){
  //   if(err) console.error(err);
  // })
  
  // nateshKitty2.save(function (err, nateshKitty2){
    //   if(err) console.error(err);
    // })
    
    // upar yeh humne jo model mei 2 objects Id's mei data put kiya hai 
    // banaye woh save krwaya hai hamri collection mei
    
    
    // as we find our data in database by this method in Powershell "db.collectionname.find()" 
// e.g in this case we'll find: "db.nitus.find()" "nitus" cuz it's our collection name which 
// has stored 
// now we'll find in Node js by this method

// nitu.find(function (err, nat) {
  //   if (err) return console.error(err);
  //   console.log(nat);
  // })
  
  // jese hi hum yeh lihengy toh hamare humne same wohi result ayega jo Powershell mei ata hai 
  // or is find object mei hum callback dusre argument mei kuch bhi likh sakte hai 
  
  
  // or hum yaha niche "node app.js" ko jitni baar run krengy utni baar yeh saved krta jayega

  
  
  
  

  
  
  
  // again Mongoose Code 
  
const mongoose = require("mongoose");
mongoose.connect('mongodb://localhost/nateshCraft', 
{useNewUrlParser: true, useUnifiedTopology: true});
  
const db = mongoose.connection;
db.on('err', console.error.bind(console,  'connection error:'))
db.once('open', function () {
  console.log("we ae connected")
})


const nituSchema = new mongoose.Schema({
  name: String
});

const nitu_Kumar= mongoose.model('nitu_Kumar', nituSchema);

const natuBhai = new nitu_Kumar({
  name: "Natesh Kumar Ji",
});

natuBhai.save(function (err, natuBhai) {
  if(err) return console.error(err)
});


nitu_Kumar.find(function (err, nitu) {
  if(err) return console.error(err);
  console.log(nitu)
});

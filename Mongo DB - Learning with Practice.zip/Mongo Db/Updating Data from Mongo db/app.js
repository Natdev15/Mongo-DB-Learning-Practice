// Updating data in Mongo db 

// steps: 
// 1. show dbs 
// 2. use nateshCraft
// 3. show collections 


db.items.find()
// jo bhi "items" collection mei hoga woh show hoga 



// we can modifiy or update one thing with "updateOne()" function 
db.items.updateOne({name: "Natesh"}, {$set: {age:24} } )
// yeh hamari collection k andhr database mei jo name "natesh" naam ka hoga usmei 
// uski jitni bhi age hogi woh ussey hokar modify hogi or age: "24" hojayegi


// ya hum chahe direct phle jo find krna chahe woh krke samne lakar 
// phir usko modify kre like:
db.items.find({name: "Natesh"})


// phir yeh likh sakte hai again or data modify krsate hai
db.items.updateOne({name: "Natesh"}, {$set: {age:24} } )


// then 
db.items.find({name: "Natesh"})
// likhengy toh modified samen ajayega age: 24 k sath 


// then again 
db.items.find()
// likho then dubara sab dikho "items" collection mei hai data woh 


// we can modifiy or update many thing with "updateMany()" function 
db.items.updateMany({name: "Natu"}, {$set: {age:23, city:"mpk"} } )
// issey jo jo name: "Natu" k houngy un sabko update krdehga 
// age: 23 krdhega or agar city: nhi hoga phle data toh yeh inserted krdehga 



// then 
db.items.find()
// kro toh nazar ajayega ya phir
db.items.find({name: "Natu"})
// then we'll see sarrey name "Natu" wale modified houngy 


// then 
db.items.find() 
// then yeh likho
db.items.find({name: "Nitu"})
// phir name "Nitu" k sarey ajayengy 

db.items.updateOne({name: "Nitu"}, {$get: {age:18, city: "mpk"}})
// issey yeh hoga k 1 hi "Nitu" name wala modify hoga Many Multiple or ismei 1 hi 
// one by one so yeh hai rule or agar "city" name ka koi data nhi hoga
// toh yeh add krwadehga jo hum chahe woh
// means hum agar 1 data ko update krna chahte hai or usmei 1 ya 2 ya jitni chahe cheezei 
// modify ya update krsakte hai 


// Deleting data from Mongo db 

// steps: 
// 1. show dbs 
// 2. show collections 
// 3. use nateshCraft


db.items.find({age: 20})
// ismei yeh hoga k jis jis mei age: 20 ayegi woh samne ayega

db.item.deleteOne({age:20})
// ismie yeh hoga k jo list ayi thi age:20 thi jis jis mei usmei se 1 delete hojayega 


db.item.deleteOne({age:20})
// ismei phir 1 or delete hojayega jismei age: 20 hogi woh 


// agar hum chahte hai k sarrey delete hojaye 1 sath bar bar na krne parhe phir chahe 
// 1 ho ya infinte ya multiple so:
db.item.deleteMany( {age:20} )
// ismei yeh hoga k sarey delete hojayengy jismie age 20 thi or hai 


// yeh Deleting or Inserting dono same hai har cheez mei bas usmei find tha
// or yaha deleting hai same inserting ki tarah 2 functions
// 1. insertingOne() or deleteOne() & 2. indertingMany( {} ) or deleteMany( {} ) 

// "AND Operator" with "deleteOne()" function 
db.items.deleteOne({age: {$gt: 20 }, rating: {$gt: 7.9} })
// ismei yeh hoga k jiski age 20 se greater hogi woh or rating 7.9 hogi woh wala 1 data 
// delete hoajyega dono conditions true hui toh hi dee=lete hoga otherwise nhi 


// "AND Operator" with "deleteMany()" function 
db.items.deleteMany( {age: {gte: 19}, rating: {lt: 8} })
// ismie yeh hoga ka jiski age 19 k barabr ya greater hogi woh or jiski rating less than 8 hogi
// woh wale sarey data delete hoajyega dono conditions true hui toh hi delete hogi otherwise nhi 



// "OR Operators" with deleteOne() function 
db.items.deleteOne( {
    $or: [ {age: {gt: 20} }, {rating: {gt: 9} } ]
})
// ismei yeh hoga ka jiski age 20 se greater hogi woh ya 
// jiski rating 9 se greater hogi woh wala data delte hojayega or 1 hi hoga  


// "OR Operators" with deleteMany() function 
db.items.deleteMany( {
    $or: [ {age: {gt: 20} }, {rating: {gt: 9} } ]
})
// ismei yeh hoga ka jiski age 20 se greater hogi woh ya 
// jiski rating 9 se greater hogi woh wale sarey data delete hojayega or sarey 1 sath  